<?php
	echo "Executing...";
    shell_exec("echo Ciso0|sudo setsid sh -c 'exec /var/www/html/readRecipe <> /dev/tty2 2>&1'",$out);
	print_r($out);
?>